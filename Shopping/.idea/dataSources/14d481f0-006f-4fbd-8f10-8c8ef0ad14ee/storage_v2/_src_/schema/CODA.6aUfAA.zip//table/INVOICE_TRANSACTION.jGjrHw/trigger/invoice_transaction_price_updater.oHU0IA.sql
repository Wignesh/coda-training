create definer = root@`%` trigger invoice_transaction_price_updater
    before insert
    on INVOICE_TRANSACTION
    for each row
BEGIN
    SET NEW.`PRICE` = (SELECT PRICE FROM ITEM_MASTER WHERE ITEM_MASTER.ITEM_ID = NEW.ITEM_ID) * NEW.QTY;
END;

